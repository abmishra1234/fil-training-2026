"""Creates 15 deliberately insecure copies of the reference solution (one flaw each).
Usage: python make_mutants.py, then: python grade.py --workdir <mutants/NAME>  (expect failures)."""
import shutil, pathlib, sys
HERE = pathlib.Path(__file__).resolve().parent
SRC = HERE.parent / "solution"
M = {
 "no_bola": [("store.py", "        if user.role in (\"FINANCE_ADMIN\", \"AUDITOR\"):\n            return True", "        return True")],
 "alg_not_pinned": [("security.py", "algorithms=[ALGORITHM],", "algorithms=[\"HS256\", \"HS384\", \"HS512\"],")],
 "no_lockout": [("config.py", "lockout_threshold: int = 5", "lockout_threshold: int = 10000")],
 "user_enum": [("routers_auth.py", "        if user is not None:\n            st.login_guard.fail(username)", "        if user is None:\n            raise ApiError(401, \"invalid_credentials\", \"Unknown user\")\n        st.login_guard.fail(username)")],
 "regex_search": [("routers_expenses.py", "if \"q\" in f and f[\"q\"] not in e[\"description\"].casefold():", "if \"q\" in f and not re.search(f[\"q\"], e[\"description\"].casefold()):")],
 "self_approval": [("routers_expenses.py", "        if e[\"employee_id\"] == user.id:", "        if False:")],
 "no_idempotency": [("routers_expenses.py", "        if prior is not None:", "        if False:")],
 "no_headers": [("main.py", "            for k, v in SECURITY_HEADERS.items():", "            for k, v in {}.items():")],
 "logs_password": [("routers_auth.py", "reason=\"bad_credentials\")", "reason=\"bad_credentials\", attempted=password)")],
 "lenient_params": [("routers_expenses.py", "        if k not in ALLOWED_PARAMS:", "        if False:")],
 "no_rate_limit": [("config.py", "login_rate_limit_per_minute=_int(env, \"LOGIN_RATE_LIMIT_PER_MINUTE\", 10, 1, 100000)", "login_rate_limit_per_minute=100000")],
 "weak_secret_ok": [("config.py", "if len(secret.encode()) < 32:", "if len(secret.encode()) < 1:")],
 "trust_token_role": [("deps.py", "    request.state.user_id = user.id\n", "    import jwt as _j\n    r = _j.decode(token.strip(), options={'verify_signature': False}).get('role')\n    if r:\n        from dataclasses import replace\n        user = replace(user, role=r)\n    request.state.user_id = user.id\n")],
 "leaky_errors": [("main.py", "return envelope(400, \"validation_error\", \"Invalid request\")", "return envelope(400, \"validation_error\", str(exc))"),
                  ("http_utils.py", "raise validation(\"Request body must be valid JSON\")", "raise validation(\"JSON error: ValueError at File \\\"http_utils.py\\\"\")")],
 "skip_level": [("store.py", "return user.role == \"MANAGER\" and owner is not None and owner.manager_id == user.id", "return user.role == \"MANAGER\"")],
}
for name, edits in M.items():
    d = HERE / name; shutil.rmtree(d, ignore_errors=True); shutil.copytree(SRC, d)
    for f, a, b in edits:
        p = d / "app" / f; s = p.read_text()
        assert a in s, (name, a); p.write_text(s.replace(a, b, 1))
print(" ".join(M))
