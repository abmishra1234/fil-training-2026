# Expense Claims API Challenge — Trainer Runbook

This is the **trainer-only master kit** for the Secure API Challenge. It contains the student handout, hidden reference implementation, post-freeze judge, sample reports, and presentation material.

> Share the student kit at kick-off, share the judge only after code freeze, and keep the reference solution hidden until judging is complete.

Student teams build three secure REST APIs for an expense-claims system in any language or framework. The black-box judge evaluates each service over HTTP with **436 test cases** in ten categories.

## 1. Complete solution structure

```text
trainer-kit-01102026/
├── README.md                         # This trainer runbook
├── Expense_API_Student_Kit.zip       # Share at challenge kick-off
├── Expense_API_Judge_Release.zip     # Share only after code freeze
├── EXERCISE.pdf                      # Trainer copy of the specification
├── Verification_Guide.pdf            # Detailed verification reference
├── Sample_Submission_Reference.pptx  # Example three-slide submission
├── Solution_Walkthrough.pptx         # Post-activity walkthrough
├── seed/seed_data.json               # Canonical users, claims, threshold
├── solution/                         # Hidden FastAPI reference solution
│   ├── README.md
│   ├── requirements.txt
│   ├── seed/seed_data.json
│   └── app/
│       ├── __main__.py               # `python -m app` entry point
│       ├── config.py                 # Environment validation, safe startup
│       ├── main.py                   # Middleware, errors, headers, CORS
│       ├── routers_auth.py           # Login, rate limiting, lockout
│       ├── routers_expenses.py       # Listing, filtering, approval workflow
│       ├── security.py               # Password hashing and JWT validation
│       ├── deps.py                   # Authentication and role dependencies
│       ├── store.py                  # Seed-backed in-memory store
│       ├── http_utils.py             # Strict JSON/content-size validation
│       ├── errors.py                 # Standard API errors
│       └── logging_utils.py          # Structured security logs
├── judge/                            # Judge configured for `solution/`
│   ├── README.md                     # Judge operator instructions
│   ├── TEST_CATALOGUE.md             # Requirement-to-test mapping
│   ├── judge_config.json             # Start command and work directory
│   ├── grade.py                      # Scoring/report generator
│   ├── harness.py                    # Candidate process lifecycle
│   ├── oracle.py                     # Independent filtering oracle
│   ├── checks.py / conftest.py       # Assertions and pytest integration
│   └── tests/test_01_...test_13_*.py  # 436 executed cases
├── reports/                          # Reference/demo reports
└── mutants/                          # Trainer validation utility
```

### What to share and when

| Stage | Share with teams | Keep trainer-only |
|---|---|---|
| Kick-off | `Expense_API_Student_Kit.zip` | Solution, judge, reports, mutants, answer decks |
| Build | Exercise clarifications only | Judge tests and reference code |
| Code freeze | Ask teams to commit/tag final code | Do not release the judge early |
| Judge | `Expense_API_Judge_Release.zip` | Reference solution and reports |
| Debrief | Walkthrough and sample submission | Any material reserved for reuse |

## 2. Trainer preparation

Use Python 3.11 or newer. These commands are for Windows PowerShell and run from the repository root.

### 2.1 Verify both distributable ZIPs

```powershell
Get-FileHash .\Expense_API_Student_Kit.zip -Algorithm SHA256
Get-FileHash .\Expense_API_Judge_Release.zip -Algorithm SHA256
tar -tf .\Expense_API_Student_Kit.zip
tar -tf .\Expense_API_Judge_Release.zip
```

The student ZIP must contain only the exercise, seed, README, and three-slide template—not the solution or judge tests.

### 2.2 Create the trainer environment

```powershell
python -m venv .venv-trainer
.\.venv-trainer\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r .\solution\requirements.txt
python -m pip install -r .\judge\requirements.txt
```

If activation is blocked, call `.\.venv-trainer\Scripts\python.exe` directly for each Python command.

### 2.3 Verify the complete reference solution

The checked-in `judge/judge_config.json` points to `../solution` and starts it with `python -m app`.

```powershell
Set-Location .\judge
python .\grade.py --team "abinash"
Set-Location ..
```

Expected result: **436 passed, 0 failed, 100/100**. Reports are created in `judge/reports/`. A judge run returns a non-zero exit code when any test fails.

Run this before training day to detect Python, package, path, firewall, or process-startup issues.

## 3. Classroom execution — step by step

### Step 1 — Introduce the challenge (10–15 minutes)

Explain the business story and success criteria without showing the implementation:

- Three APIs: login, expense list/search, and approve/reject decision.
- Four roles: employee, manager, finance administrator, and auditor.
- Functional correctness and secure design are equally important.
- Teams build from the written contract; the judge is released later.
- Submission means frozen code, a judge report, and exactly three slides.

Show the lifecycle:

```text
Analyse/design → Build/self-test → Freeze code → Release judge → Record results → Present/Q&A
```

### Step 2 — Distribute only the student kit

Share `Expense_API_Student_Kit.zip`. Do not share this repository root.

Ask teams to extract it into a new working folder and read:

1. `student-kit/README.md`
2. `student-kit/EXERCISE.md` or `EXERCISE.pdf`
3. `student-kit/seed/seed_data.json`
4. `student-kit/slides/Submission_Template.pptx`

### Step 3 — Analyse requirements and design (30–45 minutes)

Before coding, teams draft slides 1 and 2. Ask them to identify:

- Role-based and object-level access rules.
- Approval states and the inclusive Rs 50,000 threshold.
- Authentication, JWT, lockout, and rate-limit behavior.
- Validation boundaries, error envelope, request IDs, and idempotency.
- BOLA/IDOR, privilege escalation, injection, mass assignment, user enumeration, weak secrets, data leakage, and log leakage.
- The environment-variable runtime contract.

Key review question: **In what order does the decision endpoint reject authentication, role, input, visibility, self-approval, idempotency, and workflow-state failures?** The response depends on this order.

### Step 4 — Build and self-test

The judge will:

- Run the configured command from the configured project directory.
- Choose a free port and pass `APP_PORT`; `{port}` is also supported in the command.
- Supply a fresh random `JWT_SECRET` and canonical `SEED_FILE`.
- Restart the service with fresh seed data for every test module.
- Make sequential HTTP requests and inspect stdout security logs.

Every team README must state:

```text
start_cmd: command that starts the already-built service
workdir:   directory from which the command runs
```

| Stack | Example `start_cmd` |
|---|---|
| FastAPI | `uvicorn app.main:app --host 127.0.0.1 --port {port} --no-server-header` |
| Spring Boot | `java -jar target/expense-api.jar --server.port={port}` |
| ASP.NET Core | `dotnet run --project src/ExpenseApi --urls http://127.0.0.1:{port}` |
| Node/Express | `node server.js` and read `process.env.APP_PORT` |

The judge does not compile projects. Teams using Java, .NET, or TypeScript must build before freezing and test the start command from a clean terminal.

### Step 5 — Perform a pre-freeze readiness demo

Using their own tests or API client, each team demonstrates:

1. Startup using environment variables only.
2. Login returning a short-lived bearer token.
3. Employee and manager data scopes.
4. Manager approval of a small claim.
5. High-value approval moving to `PENDING_FINANCE`.
6. Finance completing that approval.
7. Idempotent replay of an identical decision.
8. Standard errors for invalid and unauthorized requests.
9. Refusal to start with unsafe production configuration.

Do not disclose judge test names. Teams should derive tests from the specification.

### Step 6 — Freeze every team's code

```powershell
git status
git add .
git commit -m "Expense API challenge code freeze"
git tag challenge-code-freeze
git rev-parse HEAD
```

Record the team name and commit SHA. For a non-Git submission, collect a read-only ZIP and record its SHA-256 checksum. No implementation fixes are allowed after this point; failures go into slide 3 analysis.

### Step 7 — Release and configure the judge

Now share `Expense_API_Judge_Release.zip`. Teams extract it next to—not over—the frozen project.

```powershell
Set-Location .\judge-release\judge
python -m venv .venv-judge
.\.venv-judge\Scripts\Activate.ps1
python -m pip install -r .\requirements.txt
```

Teams can edit `judge_config.json`:

```json
{
  "start_cmd": "python -m app",
  "workdir": "../../my-expense-api",
  "startup_timeout_seconds": 60
}
```

Or supply settings at runtime:

```powershell
python .\grade.py --team "team-falcon" --start-cmd "python -m app" --workdir "..\..\my-expense-api"
```

`--workdir` paths resolve from the current terminal directory. A `workdir` in `judge_config.json` resolves relative to that JSON file. Quote paths containing spaces.

### Step 8 — Run the judge

Full scoring run:

```powershell
python .\grade.py --team "team-falcon"
```

Focused diagnostics:

```powershell
python .\grade.py authn token --team "team-falcon"
python -m pytest .\tests\test_05_filtering.py -q -x
python .\grade.py --team "team-falcon" --verbose
```

Reports are written to:

```text
judge/reports/judge_report.md
judge/reports/judge_report.html
judge/reports/judge_report.json
```

The ten equally weighted categories are `AUTHN`, `TOKEN`, `RBAC`, `OBJECT`, `FILTER`, `INPUT`, `WORKFLOW`, `CONFIG`, `LOGGING`, and `RESILIENCE`. See `judge/TEST_CATALOGUE.md` for exact coverage.

### Step 9 — Complete slide 3 without changing code

Copy the result matrix from `judge_report.md`, or use a screenshot of `judge_report.html`. For every failure, teams state:

- Observable failure.
- Root cause.
- Security or business impact.
- Proposed fix and regression test.

The fix is explained, not applied to frozen code.

### Step 10 — Present and independently verify

- 7 minutes: exactly three slides.
- 5 minutes: peer and trainer Q&A.

Rerun the judge against the recorded frozen commit and confirm slide 3.

| Submission area | Verification |
|---|---|
| Automated judge — 50% | Report matches frozen code and scores are accurate |
| Code review — 20% | Hashing, parameterized access, secrets, pinned dependencies, fail-closed errors |
| Slides — 15% | Requirements, threats, architecture, controls, trade-offs, results |
| Q&A — 15% | Every member can explain design decisions and failures |

### Step 11 — Debrief with the hidden solution

After all results are locked, present `Solution_Walkthrough.pptx`. Use `Sample_Submission_Reference.pptx` to demonstrate the expected three-slide quality.

Explain the reference implementation as layers:

```text
Environment/config validation
        ↓
Request ID, body-size, security-header middleware
        ↓
Authentication and server-side current-user reload
        ↓
Role and object-scope authorization
        ↓
Strict input validation and idempotency
        ↓
Workflow state transition
        ↓
Standard response/error and structured security log
```

| Topic | Reference file |
|---|---|
| Safe configuration/startup | `solution/app/config.py`, `solution/app/__main__.py` |
| JWT and password protection | `solution/app/security.py` |
| Server-side identity/roles | `solution/app/deps.py` |
| Login, lockout, throttling | `solution/app/routers_auth.py` |
| Scope-first filtering/workflow | `solution/app/routers_expenses.py` |
| Seed reload/visibility | `solution/app/store.py` |
| Strict body validation | `solution/app/http_utils.py` |
| Headers, CORS, errors | `solution/app/main.py` |
| Security audit events | `solution/app/logging_utils.py` |

## 4. Optional trainer demo of the reference API

Use this for rehearsal or post-judging walkthrough only.

### 4.1 Start the reference application

PowerShell terminal 1:

```powershell
Set-Location .\solution
$env:APP_ENV = "test"
$env:APP_PORT = "8000"
$env:SEED_FILE = (Resolve-Path .\seed\seed_data.json).Path
$env:CORS_ALLOWED_ORIGINS = "https://expenses.example.com"
$env:JWT_SECRET = python -c "import secrets; print(secrets.token_urlsafe(48))"
python -m app
```

The service listens on `http://127.0.0.1:8000`. Stop with `Ctrl+C`. Restarting reloads seed state and clears decisions, counters, rate limits, and idempotency records.

### 4.2 Login as a manager and list claims

PowerShell terminal 2, from the repository root:

```powershell
$base = "http://127.0.0.1:8000/api/v1"
$loginBody = @{ username = "priya"; password = "Tall-Mango-Tree-Shade-31" } | ConvertTo-Json
$login = Invoke-RestMethod -Method Post -Uri "$base/auth/token" -ContentType "application/json" -Body $loginBody
$headers = @{ Authorization = "Bearer $($login.access_token)" }
Invoke-RestMethod -Method Get -Uri "$base/expenses?page_size=100" -Headers $headers
```

Priya sees her claims plus claims of her direct reports.

### 4.3 Show a transition and idempotent replay

Claim `1002` starts as a submitted claim owned by Priya's direct report.

```powershell
$decisionHeaders = @{
  Authorization = "Bearer $($login.access_token)"
  "Idempotency-Key" = "trainer-demo-1002"
}
$decisionBody = @{ decision = "APPROVE" } | ConvertTo-Json

Invoke-RestMethod -Method Post -Uri "$base/expenses/1002/decision" -Headers $decisionHeaders -ContentType "application/json" -Body $decisionBody
Invoke-RestMethod -Method Post -Uri "$base/expenses/1002/decision" -Headers $decisionHeaders -ContentType "application/json" -Body $decisionBody
```

Both calls return the stored successful result, but the transition and `expense_decided` event happen only once.

### 4.4 Show fail-safe production startup

Stop the service. In a fresh terminal opened in `solution/`:

```powershell
Remove-Item Env:JWT_SECRET -ErrorAction SilentlyContinue
$env:APP_ENV = "prod"
$env:SEED_FILE = (Resolve-Path .\seed\seed_data.json).Path
python -m app
$LASTEXITCODE
```

The process must exit non-zero without revealing a secret.

## 5. How the judge works

- `grade.py` runs pytest, aggregates cases, prints a scoreboard, and creates Markdown/HTML/JSON reports.
- `harness.py` finds a free port, generates a secret, passes the required environment, starts the candidate, waits for readiness, and stops it.
- Every test module receives a fresh application and canonical seed state.
- An independent oracle calculates expected filtering, sorting, and pagination.
- Stdout is captured to verify JSON security events and absence of secrets.
- Production tests intentionally use missing/unsafe settings and expect fast failure.
- Performance checks use sequential calls and p95 thresholds, not concurrent load.

Do not edit the judge, tests, or canonical seed while assessing teams. If infrastructure must be repaired, document it and apply the same judge version to all teams.

## 6. Troubleshooting

| Symptom | Likely cause | Check |
|---|---|---|
| Candidate did not start | Wrong workdir, missing build/dependency, ignored port, startup failure | Run the exact command from the resolved workdir; read the judge log tail |
| Connection timeout | Fixed port or wrong interface | Listen on `127.0.0.1:$env:APP_PORT` |
| Seed not found | Project-relative assumption | Read the absolute `SEED_FILE` supplied by the judge |
| Many login/token failures | Hashing, response, signing, or claims are wrong | Run `python grade.py authn token -v` |
| 403 where 404 is expected | Existence checked before visibility | Follow the specified decision evaluation order |
| Filtering leaks data | Filters applied before scope | Compute visible records first, then filter |
| Passes alone, fails in module | State interaction | State persists within a module and resets between modules |
| Logging failures | Missing JSON/request ID, duplicate event, secret exposure | Inspect stdout and the required event table |
| Fewer than 436 cases | Subset selected or collection failed | Run `python grade.py --team "name"` without categories |
| Venv activation blocked | PowerShell policy | Invoke `.venv\Scripts\python.exe` directly |
| Judge exits non-zero | At least one case failed | The report is still generated; review it |

## 7. End-of-session checklist

- [ ] Only the student kit was shared at kick-off.
- [ ] Every team received the same specification and seed.
- [ ] Every team froze code before judge release.
- [ ] Team name and frozen commit SHA/checksum were recorded.
- [ ] Judge version/environment were consistent.
- [ ] Full judge report was preserved.
- [ ] Slide 3 matches the frozen-code report.
- [ ] No post-freeze fixes were scored.
- [ ] Presentations used exactly three slides.
- [ ] Reference material was shown only during debrief.

For exhaustive requirement coverage, read `judge/TEST_CATALOGUE.md`. For the short judge operator guide, read `judge/README.md`.
