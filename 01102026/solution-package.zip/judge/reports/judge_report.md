# Judge report - abinash

**Score: 100.0 / 100**  �  436 passed � 0 failed � 436 total  �  2026-10-01 11:26:29  �  42s

## Result matrix (copy to slide 3)

| Category | What it checks | Total | Passed | Failed | Points |
|---|---|---:|---:|---:|---:|
| AUTHN | Login & token issuance (A07, A04) | 23 | 23 | 0 | 10.0 |
| TOKEN | Token validation (A07, A08) | 37 | 37 | 0 | 10.0 |
| RBAC | Role-based access control (A01) | 12 | 12 | 0 | 10.0 |
| OBJECT | Object-level authZ & data scope (A01) | 23 | 23 | 0 | 10.0 |
| FILTER | Filtering, sorting & pagination | 71 | 71 | 0 | 10.0 |
| INPUT | Input validation & injection (A05) | 122 | 122 | 0 | 10.0 |
| WORKFLOW | Business rules & idempotency (A06) | 30 | 30 | 0 | 10.0 |
| CONFIG | Security configuration & hardening (A02) | 62 | 62 | 0 | 10.0 |
| LOGGING | Security logging & alerting (A09) | 9 | 9 | 0 | 10.0 |
| RESILIENCE | Exceptional conditions & NFRs (A10, NFR) | 47 | 47 | 0 | 10.0 |
| **Total** | | **436** | **436** | **0** | **100.0** |

