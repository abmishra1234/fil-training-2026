# Expense Claims API: reference solution (trainer only)

FastAPI + Uvicorn, in-memory store rebuilt from the seed file on every start. Judge result: 436 passed, 0 failed (100/100).

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export APP_ENV=test APP_PORT=8000 SEED_FILE=seed/seed_data.json CORS_ALLOWED_ORIGINS=https://expenses.example.com
export JWT_SECRET=$(python -c "import secrets;print(secrets.token_urlsafe(48))")
python -m app            # judge start_cmd: "python -m app"
```

Grade it: `cd ../judge && python grade.py --team reference-solution` (judge_config.json already points here).

| File | Responsibility |
|---|---|
| `app/__main__.py` | loads settings, exits 1 on unsafe config, starts Uvicorn (no Server header) |
| `app/config.py` | env-only configuration, secure defaults (A02) |
| `app/security.py` | Argon2id hashing, JWT create/verify with pinned HS256 (A04/A07/A08) |
| `app/deps.py` | `get_current_user`, `require_role`: user reloaded from the store every request (A01/A07) |
| `app/routers_auth.py` | API 1 + LoginGuard (lockout, per-IP rate limit) |
| `app/routers_expenses.py` | API 2 (strict filters, scope first) + API 3 (ordered checks, idempotency, state machine) |
| `app/http_utils.py` | 415 / 413 / strict JSON object parsing (A05/A10) |
| `app/logging_utils.py` | JSON security events on stdout with redaction (A09) |
| `app/main.py` | error envelope, security headers, CORS allow-list, request id, fail-closed 500 |
